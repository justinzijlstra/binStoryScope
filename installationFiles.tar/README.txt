sudo apt-get -y install v4l2loopback-dkms
sudo apt-get -y install v4l-utils
sudo apt install ffmpeg


install teamviewer
installDep.sh

install reactivision id 0 ?
installstuff.sh
copy Builds
copy StoryScopeMedia