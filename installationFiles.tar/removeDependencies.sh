#!/bin/bash

#NOT TESTED
sudo apt purge v4l2loopback-dkms
wait
sudo apt purge v4l-utils
wait
sudo apt purge ffmpeg
